package com.mapsea.core.routeplan;

public enum MOCategory {
    WAYPOINT,
    DEPTH,
    INTEREST,
    BUOY,
    SERVICE,
    OBSTRUCTION,
    WRECK
}
