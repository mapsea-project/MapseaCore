package com.mapsea.core.routeplan;

public enum VesselDisplayMode {
    PENTAGON,
    TRIANGLE,
    DOT,
    NONE
}
