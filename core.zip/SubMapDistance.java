package com.mapsea.core.routeplan;

public class SubMapDistance {
    public int distance;
    public int latIndex;
    public int lonIndex;
}
