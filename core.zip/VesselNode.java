package com.mapsea.core.routeplan;

import java.util.LinkedList;

public class VesselNode extends LinkedList<Vessel> {

}