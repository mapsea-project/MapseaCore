package com.mapsea.core.routeplan;

/** 좌표 데이터(int)<br>
 * x: longitude
 * y: latitude
 * */
public class Point2I {
    public int X;
    public int Y;

    public Point2I(int x, int y)
    {
        X = x;
        Y = y;
    }
}
