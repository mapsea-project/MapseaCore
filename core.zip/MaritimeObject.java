package com.mapsea.core.routeplan;

import com.mapsea.core.routeplan.MOCategory;

public class MaritimeObject {
    public MOCategory _cat;
    //public image _img;
    public double _lat;
    public double _lon;
    public double _depth;
    public String _txt;
}
